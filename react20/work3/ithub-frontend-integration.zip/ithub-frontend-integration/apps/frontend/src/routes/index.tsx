import { createFileRoute, redirect, Link } from '@tanstack/react-router'

export const Route = createFileRoute('/')({
  beforeLoad: async ({ context }) => {
    // Требование: если пользователь залогинен, происходит перенаправление на страницу /records
    if (context.accessToken) {
      throw redirect({ to: '/records' })
    }
  },
  component: LandingPage,
})

function LandingPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-50 px-4">
      <div className="w-full max-w-2xl rounded-2xl bg-white p-8 shadow-md text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">FastAPI Integration</h1>
        <p className="text-gray-600 mb-8">
          Добро пожаловать в сервис управления заявками. Войдите в систему или зарегистрируйтесь, чтобы просматривать и создавать заявки.
        </p>

        {/* Блок действия с ссылкой на вход / регистрацию */}
        <div className="flex justify-center gap-4 mb-8">
          <Link
            to="/login"
            className="rounded-lg bg-indigo-600 px-6 py-2.5 text-white font-medium hover:bg-indigo-700 transition-colors shadow-sm"
          >
            Войти
          </Link>
          <Link
            to="/register"
            className="rounded-lg border border-indigo-600 px-6 py-2.5 text-indigo-600 font-medium hover:bg-indigo-50 transition-colors"
          >
            Регистрация
          </Link>
        </div>

        <div className="rounded-xl border border-gray-100 bg-gray-50 p-6 text-left">
          <h2 className="text-lg font-semibold text-gray-800 mb-2">О курсах</h2>
          <p className="text-sm text-gray-500">
            Здесь отображается краткая информация о доступных направлениях обучения и количестве поданных заявок.
          </p>
        </div>
      </div>
    </div>
  )
}

