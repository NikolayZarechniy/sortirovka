import { forwardRef, useState } from 'react'
import { createFileRoute, createLink, redirect, useNavigate, type LinkComponent } from '@tanstack/react-router'
import apiClient from '#/api/client'
import useQuery from '#/hooks/use-query'
import type * as types from '#/types'

export const Route = createFileRoute('/record')({
  beforeLoad: async ({ context }) => {
    if (!context.accessToken) {
      throw redirect({ to: '/login' })
    }

    if (!context.username) {
      try {
        const { username } = await apiClient.auth.me({ accessToken: context.accessToken })
        return { ...context, username }
      } catch {
        context.setAccessToken(null)
        throw redirect({ to: '/login' })
      }
    }
  },
  component: RecordsPage,
})

interface BaseRecordLinkProps extends React.TableHTMLAttributes<HTMLTableRowElement> {}

const BaseRecordLink = forwardRef<HTMLTableRowElement, BaseRecordLinkProps>((props, ref) => {
  return <tr ref={ref} {...props}></tr>
})

const CreatedRecordLink = createLink(BaseRecordLink)

const RecordLink: LinkComponent<typeof BaseRecordLink> = (props) => {
  // @ts-expect-error // TODO: narrow children types
  return <CreatedRecordLink {...props} style={{ cursor: "pointer" }} />
}

function RecordsPage() {
  const { accessToken, username, setAccessToken } = Route.useRouteContext()
  const navigate = useNavigate()
  const [deletingId, setDeletingId] = useState<number | null>(null)

  const {
    data: records,
    isLoading,
    error,
    mutate: refetchRecords,
  } = useQuery<types.RecordItem[], types.RecordQueryParams>({
    initialData: [],
    queryFn: apiClient.records.all,
    queryParams: {
      accessToken,
      authorId: username,
    },
  })

  // Функция логаута
  const handleLogout = () => {
    setAccessToken(null)
    localStorage.removeItem('token')
    navigate({ to: '/login' })
  }

  // Функция удаления заявки с подтверждением (Бонус: перед удалением запрашивать подтверждение)
  const handleDelete = async (e: React.MouseEvent, id: number) => {
    e.preventDefault() // предотвращаем переход по ссылке строки
    e.stopPropagation()

    const isConfirmed = window.confirm(`Вы уверены, что хотите удалить заявку №${id}?`)
    if (!isConfirmed) return

    try {
      setDeletingId(id)
      await apiClient.records.delete({ accessToken, id })
      // Обновляем список после удаления
      refetchRecords()
    } catch (err: any) {
      alert(err.message || 'Ошибка при удалении заявки')
    } finally {
      setDeletingId(null)
    }
  }

  if (error) {
    return (
      <div className="p-8 max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-red-600 mb-2">Ошибка</h1>
        <p className="text-gray-700">{error.message}</p>
      </div>
    )
  }

  return (
    <div className="p-8 max-w-6xl mx-auto">
      {/* Шапка с информацией о пользователе и логаутом */}
      <div className="flex justify-between items-center mb-6 border-b pb-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Список заявок</h1>
          <p className="text-sm text-gray-600 mt-1">
            Пользователь: <span className="font-semibold text-indigo-600">{username}</span>
          </p>
        </div>
        <div className="flex gap-3">
          <Link
            to="/records/create"
            className="rounded-lg bg-indigo-600 px-4 py-2 text-sm text-white font-medium hover:bg-indigo-700 transition-colors"
          >
            Создать заявку
          </Link>
          <button
            onClick={handleLogout}
            className="rounded-lg border border-gray-300 px-4 py-2 text-sm text-gray-700 font-medium hover:bg-gray-100 transition-colors"
          >
            Выйти
          </button>
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center py-20">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-indigo-600 border-t-transparent"></div>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-gray-200 bg-white shadow-sm">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200 text-xs font-semibold uppercase text-gray-500">
                <th className="p-4">№</th>
                <th className="p-4">Курс</th>
                <th className="p-4">Создан</th>
                <th className="p-4 text-right">Действия</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 text-sm">
              {!records?.length ? (
                <tr>
                  <td colSpan={4} className="p-8 text-center text-gray-500">
                    Записей пока нет
                  </td>
                </tr>
              ) : (
                records.map(({ id, course, created_at }) => (
                  <RecordLink
                    to="/records/$id"
                    params={{ id }}
                    key={id}
                    className="hover:bg-gray-50 transition-colors"
                  >
                    <td className="p-4 font-medium text-gray-900">№ {id}</td>
                    <td className="p-4 text-gray-700">{course?.title || '—'}</td>
                    <td className="p-4 text-gray-500">{new Date(created_at).toLocaleString()}</td>
                    <td className="p-4 text-right">
                      <button
                        onClick={(e) => handleDelete(e, id)}
                        disabled={deletingId === id}
                        className="rounded-md bg-red-50 px-3 py-1.5 text-xs font-medium text-red-600 hover:bg-red-100 transition-colors disabled:opacity-50"
                      >
                        {deletingId === id ? 'Удаление...' : 'Удалить'}
                      </button>
                    </td>
                  </RecordLink>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
