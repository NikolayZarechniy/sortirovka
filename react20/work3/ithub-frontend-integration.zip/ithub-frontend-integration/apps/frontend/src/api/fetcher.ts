const baseUrl = 'http://127.0.0.1:8000'

type ContentType = "x-www-form-urlencoded" | "json"

type Headers = {
    Authorization?: `Bearer ${string}`;
    "Content-Type"?: `application/${ContentType}`;
}

type SearchParams = Record<string, string | number>

type FetcherOptions = {
    path: `/${string}`;
    headers: Headers;
    method: 'get' | 'post';
    body?: string | URLSearchParams;
    searchParams?: SearchParams
}

export default async <ResultType = void>({ path, headers, method, body, searchParams = {} }: FetcherOptions): Promise<ResultType> => {
    try {
        const url = new URL(path, baseUrl)

        for (const [param, value] of Object.entries(searchParams)) {
            url.searchParams.append(param, String(value))
        }

        // Автоматически превращаем объект в JSON-строку, если это не URLSearchParams и не строка
        let requestBody = body;
        if (body && typeof body === 'object' && !(body instanceof URLSearchParams)) {
            requestBody = JSON.stringify(body);
        }

        const requestInit: RequestInit = {
            credentials: 'include',
            method,
            headers,
        }

        if (requestBody !== undefined) {
            requestInit.body = requestBody;
        }

        const response = await fetch(url.toString(), requestInit)

        if (!response.ok) {
            // Пытаемся прочитать текст ошибки с бэкенда (FastAPI возвращает детали в поле detail)
            const errorData = await response.json().catch(() => ({}));
            
            let errorMessage = 'Сетевая ошибка';
            if (typeof errorData.detail === 'string') {
                errorMessage = errorData.detail;
            } else if (Array.isArray(errorData.detail)) {
                // Ошибки валидации Pydantic
                errorMessage = errorData.detail.map((err: any) => `${err.loc.join('.')}: ${err.msg}`).join(', ');
            }

            throw new Error(errorMessage);
        }

        // Если ответ пустой (например, 204), возвращаем undefined
        const text = await response.text();
        return text ? JSON.parse(text) : (undefined as ResultType);
    } catch (error) {
        console.error('Fetcher error:', error)
        throw error
    }
}

